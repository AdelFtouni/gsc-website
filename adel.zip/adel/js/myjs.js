function ffff(){

    document.getElementById('navs-pills-justified-home').style.display = "none";
    document.getElementById('accordionOne').style.display = "none";
    document.getElementById('accordionTwo').style.display = "none";
    document.getElementById('accordionTwo').style.display = "none";
}